import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report
import tensorflow as tf
from tensorflow.keras import layers, models
import pickle
from datetime import datetime
from sklearn.ensemble import RandomForestClassifier

def prepare_features(df):
    # Convert created_at to datetime
    df['created_at'] = pd.to_datetime(df['created_at'])
    
    # Calculate followers to friends ratio
    df['followers_friends_ratio'] = df['followers_count'] / df['friends_count'].replace(0, 1)
    
    # Profile completeness score
    df['has_description'] = df['description'].notna().astype(int)
    df['has_location'] = df['location'].notna().astype(int)
    df['has_url'] = df['url'].notna().astype(int)
    
    # Convert boolean strings to integers if needed
    df['default_profile'] = df['default_profile'].astype(int)
    df['default_profile_image'] = df['default_profile_image'].astype(int)
    
    # Select final features (without account_age_days)
    features = [
        'statuses_count',
        'followers_count',
        'friends_count',
        'favourites_count',
        'listed_count',
        'followers_friends_ratio',
        'default_profile',
        'default_profile_image',
        'has_description',
        'has_location',
        'has_url'
    ]
    
    return df[features]

def extract_features(user):
    features = {
        # Activity metrics
        'statuses_to_followers_ratio': user['statuses_count'] / (user['followers_count'] + 1),
        'friends_to_followers_ratio': user['friends_count'] / (user['followers_count'] + 1),
        'favourites_count': user['favourites_count'],
        'listed_count': user['listed_count'],
        
        # Profile completeness
        'has_description': len(user['description'].strip()) > 0,
        'has_location': len(user['location'].strip()) > 0,
        'has_url': user['url'] is not None,
        'default_profile': user['default_profile'] == '1',
        'default_profile_image': user['default_profile_image'] == '1',
        
        # Profile customization
        'has_profile_banner': user['profile_banner_url'] != 'NULL',
        'has_background_image': len(user['profile_background_image_url'].strip()) > 0,
        
        # Account age (in days from creation to updated)
        'account_age': (pd.to_datetime(user['updated']) - pd.to_datetime(user['created_at'])).days
    }
    return features

def build_fake_detection_model():
    # 1. Load and preprocess data
    fusers_df = pd.read_csv('dataset/fusers.csv')  
    users_df = pd.read_csv('dataset/users.csv')
    
    # 2. Extract features
    X = []
    y = []
    
    for _, user in fusers_df.iterrows():
        X.append(extract_features(user))
        y.append(1)  # fake
        
    for _, user in users_df.iterrows():
        X.append(extract_features(user))
        y.append(0)  # real
    
    # 3. Train model (using Random Forest as an example)
    X = pd.DataFrame(X)
    model = RandomForestClassifier()
    model.fit(X, y)
    
    return model

# Load data
df = pd.read_csv('../dataset/fusers.csv')

# Prepare features
X = prepare_features(df)

# For this example, we'll assume accounts with default profile image 
# and very low followers/friends ratio are fake
# In real implementation, you'd have actual labels
y = ((df['default_profile_image'] == 1) & 
     (df['followers_count'] / df['friends_count'].replace(0, 1) < 0.1)).astype(int)

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Create model
model = models.Sequential([
    layers.Dense(64, activation='relu', input_shape=(X_train.shape[1],)),
    layers.Dropout(0.3),
    layers.Dense(32, activation='relu'),
    layers.Dropout(0.2),
    layers.Dense(16, activation='relu'),
    layers.Dense(1, activation='sigmoid')
])

# Compile model
model.compile(optimizer='adam',
              loss='binary_crossentropy',
              metrics=['accuracy'])

# Train model
history = model.fit(X_train_scaled, y_train,
                    epochs=50,
                    batch_size=32,
                    validation_split=0.2,
                    verbose=1)

# Evaluate model
y_pred = (model.predict(X_test_scaled) > 0.5).astype(int)
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Save model and scaler
model.save('twittermodel.h5')
with open('twittermodel_scaler.pkl', 'wb') as scaler_file:
    pickle.dump(scaler, scaler_file)

def predict_fake_account(user_data):
    """
    Predict if a Twitter account is fake based on its features
    
    Parameters:
    user_data: dict containing user features
    
    Returns:
    str: "Fake" or "Genuine"
    """
    # Prepare features
    features = pd.DataFrame([user_data])
    features = prepare_features(features)
    
    # Scale features
    features_scaled = scaler.transform(features)
    
    # Make prediction
    prediction = model.predict(features_scaled)
    return "Fake" if prediction[0] > 0.5 else "Genuine" 