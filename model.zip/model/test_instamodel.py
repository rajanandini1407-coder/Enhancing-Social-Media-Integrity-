import numpy as np
import tensorflow as tf
import pickle

def load_model_and_scaler():
    # Load the trained model
    model = tf.keras.models.load_model('instamodel.h5')
    
    # Load the scaler
    with open('instamodel_scaler.pkl', 'rb') as scaler_file:
        scaler = pickle.load(scaler_file)
    
    return model, scaler

def predict_fake_account(features, model, scaler):
    # Scale the features
    features_scaled = scaler.transform([features])
    # Make prediction
    prediction = model.predict(features_scaled)
    return "Fake" if prediction[0] > 0.5 else "Genuine"

def main():
    # Load the model and scaler
    try:
        model, scaler = load_model_and_scaler()
        print("Model and scaler loaded successfully!")
        
        # Test cases
        test_cases = [
            [0.001, 0.257, 13, 1, 1, 13, 0, 0, 0, 0, 0, 0],  # Sample case 1
            [0.8, 0.9, 1000, 50, 30, 500, 1, 1, 1, 0, 1, 1],  # Sample case 2
            [0.007,0.32,15,0,0,16,0,0,0,1,0,0]      # Sample case 3
        ]
        
        # Make predictions
        for i, test_case in enumerate(test_cases, 1):
            result = predict_fake_account(test_case, model, scaler)
            print(f"\nTest Case {i}:")
            print(f"Features: {test_case}")
            print(f"Prediction: {result}")
            
    except Exception as e:
        print(f"Error occurred: {str(e)}")

if __name__ == "__main__":
    main() 