# Import necessary libraries
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, confusion_matrix
import tensorflow as tf
from tensorflow.keras import layers, models
from imblearn.over_sampling import SMOTE
import pickle

# 1. Load and prepare the data
df = pd.read_csv('../dataset/final-v1.csv')

# 2. Check for missing values and data info
print("Missing values:\n", df.isnull().sum())
print("\nClass distribution:\n", df['is_fake'].value_counts())

# 3. Separate features and target
X = df.drop('is_fake', axis=1)
y = df['is_fake']

# 4. Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 5. Scale the features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 6. Apply SMOTE for class balancing
smote = SMOTE(random_state=42)
X_train_balanced, y_train_balanced = smote.fit_resample(X_train_scaled, y_train)

# 7. Create the deep learning model
model = models.Sequential([
    layers.Dense(64, activation='relu', input_shape=(X_train.shape[1],)),
    layers.Dropout(0.3),
    layers.Dense(32, activation='relu'),
    layers.Dropout(0.2),
    layers.Dense(16, activation='relu'),
    layers.Dense(1, activation='sigmoid')
])

# 8. Compile the model
model.compile(optimizer='adam',
              loss='binary_crossentropy',
              metrics=['accuracy'])

# 9. Train the model
history = model.fit(X_train_balanced, y_train_balanced,
                    epochs=50,
                    batch_size=32,
                    validation_split=0.2,
                    verbose=1)

# 10. Evaluate the model
y_pred = (model.predict(X_test_scaled) > 0.5).astype(int)
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Save the model and scaler

# Save the model
model.save('instamodel.h5')

# Save the scaler
with open('instamodel_scaler.pkl', 'wb') as scaler_file:
    pickle.dump(scaler, scaler_file)

# 11. Plot training history
import matplotlib.pyplot as plt

plt.figure(figsize=(12, 4))

# Plot training & validation accuracy
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('Model accuracy')
plt.ylabel('Accuracy')
plt.xlabel('Epoch')
plt.legend(['Train', 'Validation'], loc='upper left')

# Plot training & validation loss
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('Model loss')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend(['Train', 'Validation'], loc='upper left')

plt.tight_layout()
plt.show()

# 12. Function to make predictions on new data
def predict_fake_account(features):
    # Scale the features
    features_scaled = scaler.transform([features])
    # Make prediction
    prediction = model.predict(features_scaled)
    return "Fake" if prediction[0] > 0.5 else "Genuine"

# Example usage
sample_features = [0.001, 0.257, 13, 1, 1, 13, 0, 0, 0, 0, 0, 0]
result = predict_fake_account(sample_features)
print(f"This account is predicted to be: {result}")
